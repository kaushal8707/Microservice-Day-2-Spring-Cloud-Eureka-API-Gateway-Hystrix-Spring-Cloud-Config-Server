package com.selfdeveloped.spring.pos.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@SpringBootApplication
@EnableEurekaClient
public class PaymentorderServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PaymentorderServiceApplication.class, args);
	}

}
