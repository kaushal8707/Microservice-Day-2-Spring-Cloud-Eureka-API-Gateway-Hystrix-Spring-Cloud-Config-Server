package com.selfdeveloped.spring.pos.api.service;
import java.util.Random;
import java.util.UUID;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.selfdeveloped.spring.pos.api.entity.Payment;
import com.selfdeveloped.spring.pos.api.repository.PaymentRepository;

@Service
public class PaymentService {

	@Autowired
	PaymentRepository paymentRepository;
	
	public Payment doPayment(Payment payment) {
		payment.setPaymentStatus(paymentProcessing()); 
		payment.setTransactionId(UUID.randomUUID().toString());
		return paymentRepository.save(payment);
	}
	
	
	public String paymentProcessing() {
		//api should be 3rd party payment gateway (PayPal, paytm, GooglePay…)
		return new Random().nextBoolean()?"Success":"Failed";
	}


	public Payment findPaymentHistoryByOrderId(int orderId) { 
		return paymentRepository.findByOrderId(orderId);
	}
	
}
